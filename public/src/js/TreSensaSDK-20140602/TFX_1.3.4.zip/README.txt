PLEASE NOTE: If you have a version of TFX prior to 1.3.4 already installed, you MUST uninstall it before installing the latest version.

This zip file includes:

TFX_*.exe
--------------------------------------
The TFX installer for Windows. Will install Adobe AIR runtime automatically if required.


TFX_*.air
--------------------------------------
TFX as an Adobe AIR application that will work on Windows or Mac, provided you already have the Adobe AIR runtime installed.


Batch Export for ActionScript.jsfl
--------------------------------------
A useful script that will go through all objects in your library, convert them to MovieClips, and mark them as 'Export for ActionScript' (these are requirements for successful TFX conversion). The script will also attempt to fix invalid MovieClip names, and will change all bitmap settings to "lossless" and "allow smoothing" (again, recommended for TFX conversion).

To install, simply copy the .jsfl file into the Commands folder in your Adobe Flash install path (for instance C:\Users\[USER]\AppData\Local\Adobe\Flash CS6\en_US\Configuration\Commands). Then restart Adobe Flash. Once installed a "Batch Export for ActionScript" item will be available in the Commands menu.


FAQ & Setup Help PDFs
--------------------------------------
A couple of helpful pdf files addressing common questions and problems.


Sample folder
--------------------------------------
Contains a sample character animation in swf and Flash format, as well as the html5 output created by TFX.