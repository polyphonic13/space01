The TreSensa SDK consists of:

lib - All TreSensa javascript libraries and related 3rd party libraries.

starter_template - empty game project is a minimal TGE based project of you to begin coding your game from scratch.

Spider - demo project for you to modify and use as a basis for your own game. It uses most TGE and TGS features.

TFX_1.3.4.zip - Windows, Mac, and Linux versions of TreSensa Flash Animation Exporter

Use of the TreSensa SDK requires acceptance of the evaluation license terms at http://www.tresensa.com/software-evaluation-agmt